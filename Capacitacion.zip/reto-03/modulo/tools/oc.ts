// Reutilización del mismo módulo de herramientas de la aplicación.
// Integradores externos pueden importar `tools` y `runTool` desde el código fuente:
export { tools, runTool, saveValidation } from '../../src/tools/oc.js';
