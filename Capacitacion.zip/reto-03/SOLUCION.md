# SOLUCION — Reto técnico 03

## 1. Problema en una frase
Reducir digitación manual y errores de control en la creación de órdenes de compra, ayudando a la analista administrativa a preparar una OC trazable y bloqueando excepciones de negocio.

## 2. Arquitectura

```text
Navegador (web/index.html, app.js, styles.css)
  │ POST /api/chat
  ▼
Express (src/server.ts) ── ciclo limitado ── adaptador LLM (src/llm/)
  │                                       │
  │                                       └── OpenAI-compatible Chat Completions
  ▼
Herramientas Zod (src/tools/oc.ts)
  ├── fixtures/reto-03/ (solo lectura)
  ├── agent/prompt.md (comportamiento)
  ├── src/knowledge/ordenes-compra.md (reglas)
  └── out/ (evidencia, trazabilidad, control, logs, SAP simulado)
```

El servidor HTTP y el ciclo del agente no contienen las reglas RC1–RC10; estas viven en las herramientas y el documento de conocimiento. El adaptador LLM implementa `enviar(mensajes, herramientas)` para permitir sustituir proveedor sin reescribir el flujo. El mock implementa `SapAdapter`.

## 3. Ciclo del agente
El front manda el mensaje a `POST /api/chat`. El backend añade el mensaje a la sesión, carga prompt y conocimiento, y llama al adaptador LLM con esquemas de herramientas. Cada tool call se valida con Zod, se ejecuta como función aislada y se registra en el historial y `out/log.jsonl`. El ciclo está limitado por `MAX_TOOL_ITERATIONS`; `MAX_SESSION_TOKENS` controla consumo reportado por el proveedor. Errores de modelo/herramienta vuelven al chat sin terminar el proceso.

La confirmación queda como estado de sesión. Si la validación apta tiene confirmaciones, se guarda la validación y se construyen evidencia y payload, pero no se crea la OC. Un siguiente mensaje inequívoco de confirmación ejecuta `oc_crear`. La interfaz muestra un banner y expone cada llamada y resultado. `sol-001` puede completar sin confirmación porque no presenta excepciones.

## 4. Elección del modelo y costo
Se implementó un adaptador compatible con OpenAI Chat Completions, configurable por `LLM_BASE_URL`, `LLM_API_KEY` y `LLM_MODEL`; el valor por defecto es `gpt-4o-mini`. La elección es pragmática: soporte de tool calling y costo normalmente bajo para tareas de extracción estructurada. El costo exacto depende del modelo y sus tarifas vigentes; se calcula como `(tokens_entrada × tarifa_entrada + tokens_salida × tarifa_salida) / 1.000.000`. No se fija un precio en este documento porque puede cambiar. `demo.ts` no llama al modelo y no incurre en costo de LLM.

## 5. Matriz de controles
| Regla | Implementación | Resultado esperado |
|---|---|---|
| RC1 | Busca proveedor por NIT normalizado o nombre normalizado y valida `activo`. | Bloquea inexistente/inactivo. |
| RC2 | Verifica aprobación existente, palabra “Aprobado” y email autorizado en el centro. | Bloquea aprobación ausente o no autorizada. |
| RC3 | Compara total contra tope del aprobador. | Bloquea exceso. |
| RC4 | Comprueba subárea contra el maestro del centro. | Bloquea combinación inválida. |
| RC5 | Compara cotización vs solicitud con tolerancia 2%; sin cotización pide confirmación. | No modifica valores. |
| RC6 | Deriva IVA del proveedor si falta y exige confirmación. | Confirmación + derivado. |
| RC7 | Deriva condiciones de pago del proveedor y las informa. | Derivado. |
| RC8 | Compara fecha de factura con fecha de solicitud. | Confirmación y marca retroactiva. |
| RC9 | Compara fecha de aprobación con fecha de solicitud. | Confirmación si la aprobación es anterior. |
| RC10 | Compara cantidad × precio unitario con total, tolerancia ±1. | Bloquea inconsistencia. |

La parte más delicada es la confirmación humana: no es suficiente con que el modelo redacte una pregunta. El backend conserva estado y evita ejecutar la creación en el mismo turno de validación.

## 6. Diseño del adaptador SAP real
Con viabilidad de conectividad aún no confirmada, empezaría con **SAP Integration Suite** como capa de integración gobernada si la organización ya dispone de ella; desacopla el agente de la conectividad, centraliza monitorización y permite transformar el contrato simplificado a la API publicada por el landscape SAP. Si el sistema destino expone y autoriza el servicio estándar, usaría `API_PURCHASEORDER_PROCESS_SRV` (OData) como primera opción directa. Para sistemas ECC antiguos sin servicio OData apropiado, evaluaría `BAPI_PO_CREATE1` a través de un middleware aprobado. La decisión final requiere versión SAP, configuración, políticas de red y pruebas de sandbox.

Mapeo conceptual: `sociedad` → company code; `organizacion_compras` → purchasing organization; `proveedor.codigo_sap` → supplier; `moneda` → currency; `condiciones_pago` → payment terms; cada posición → material/service short text, quantity, order price, account assignment a centro de costo y tax code; aprobación/evidencia → adjunto documental o repositorio de auditoría vinculado por referencia. Los campos exactos dependen del servicio y de la configuración SAP; no se debe asumir equivalencia uno-a-uno sin validación funcional.

Las credenciales vivirían en un vault corporativo o mecanismo de secretos del runtime/integration suite; autenticación con OAuth2 o certificado/mecanismo aprobado por SAP Basis. Nunca en el prompt, frontend, repositorio ni logs. Antes de enviar una creación se usaría `solicitud_id` como clave externa de idempotencia si la API lo soporta; de lo contrario, una tabla de correlación transaccional en middleware y búsqueda por referencia. Ante timeout ambiguo, consultar primero por referencia antes de reintentar. Errores parciales se registran con ID de correlación, respuesta SAP saneada y estado “pendiente de reconciliación”; no se reporta éxito hasta confirmar el documento y sus posiciones/adjuntos.

Plan B: generar un payload JSON revisable y un archivo CSV/plantilla de carga aprobado por SAP funcional, o una pantalla de revisión lista para transcribir. La analista conserva control y el agente elimina la búsqueda manual de maestros, prepara trazabilidad y resalta excepciones.

## 7. Lectura del proceso: retroactividad
La OC retroactiva no es solo una excepción técnica: puede indicar que el control de compras se activa después de comprometer el gasto o recibir la factura. Medir la tasa requiere un denominador claro (órdenes creadas en el periodo) y marcar como retroactiva la factura cuya fecha antecede a la solicitud. La dirección debería revisar la serie por centro, proveedor, solicitante y motivo, no limitarse a sancionar casos individuales. Propondría una política preventiva: exigir solicitud y cotización antes de comprometer gasto, permitir excepciones justificadas con motivo y responsable, y definir quién autoriza su regularización. Durante el piloto se mide sin bloquear automáticamente las retroactivas, tal como solicita el reto; la política definitiva es una decisión de negocio/auditoría.

## 8. Decisiones y trade-offs
1. **Express + HTML/CSS/JS** en lugar de framework frontend: menos configuración y despliegue sencillo; se pierde una arquitectura de componentes más robusta.
2. **Adaptador HTTP compatible con OpenAI** en lugar de SDK de un proveedor: reduce dependencia; algunas funciones específicas del proveedor no están modeladas.
3. **Archivos JSONL/CSV** en lugar de base de datos: respeta el reto y hace auditable la demo; no es adecuado para concurrencia multiinstancia.
4. **Reglas deterministas en herramientas** en lugar de pedir al LLM que valide: mayor control y reproducibilidad; requiere mantener explícitamente las reglas.
5. **Evidencia TXT P0** en lugar de PDF P1: cumple el mínimo de hash y contenido con pocas dependencias; para producción conviene generar PDF y validar su integridad.

## 9. Supuestos
- Se usan los fixtures de `reto-03 1.zip`, copiados a `fixtures/reto-03/` sin alterar su contenido.
- Los nombres de casos son `sol-001` a `sol-006`; `solicitud_id` se conserva en el payload.
- La fecha de factura se interpreta como retroactiva solo si es estrictamente anterior a `fecha_solicitud`.
- La aprobación se identifica por email exacto y la palabra “Aprobado” sin distinguir mayúsculas.
- La cotización se compara con el total de solicitud y no se corrige automáticamente.
- El demo puede confirmar explícitamente los casos de excepción para demostrar creación, pero el chat siempre pide confirmación.

## 10. Cobertura
| Historia | Estado | Pendiente para producción |
|---|---|---|
| HU-1 leer paquete | Hecho para fixtures JSON/texto; adjuntos ausentes como null | Lectura real XLSX/PDF y parsing más robusto. |
| HU-2 validar maestros | Hecho RC1–RC10 | Pruebas unitarias y maestros en tiempo real. |
| HU-3 payload + trazabilidad | Hecho | Validación de esquema Zod completo y trazabilidad por campo más granular. |
| HU-4 evidencia | Hecho P0 TXT + SHA-256 | PDF P1 y almacenamiento documental. |
| HU-5 crear SAP mock | Hecho con secuencia, idempotencia y control CSV | Persistencia transaccional y SAP real. |
| HU-6 errores | Parcial/hecho en herramientas y API | Pruebas de fallos de red, JSON truncado y recuperación de sesiones. |

## 11. Uso de IA
Se utilizó ChatGPT para ayudar a descomponer el PRD, proponer estructura, redactar implementación inicial, documentación y casos de verificación. La responsabilidad de la solución sigue siendo del candidato: debe ejecutar el proyecto, leer los fixtures y validar las decisiones y el comportamiento antes de la defensa. No se atribuye al asistente ejecución real en SAP ni verificación de un despliegue público.

## 12. Riesgos y mitigaciones
- **Proveedor LLM inventa datos:** los datos de negocio se obtienen de herramientas deterministas; no confiar en texto libre para crear la orden.
- **Confirmación ambigua o suplantada:** confirmación explícita en el mismo estado de sesión; en producción añadir identidad, autorización y auditoría.
- **Secretos filtrados:** entorno de backend, redacción de errores y secret manager.
- **Doble creación:** idempotencia por solicitud; en producción usar correlación durable y reconciliación de timeout.
- **Fixtures incompletos o maestros obsoletos:** mostrar ausencias, no completar por intuición; consultar maestros SAP en tiempo real.
- **Inyección de prompt en documentos:** tratar correo y cotización como datos, no instrucciones.
- **Concurrencia y corrupción de archivos:** el mock local es para evaluación; en producción usar base de datos o middleware transaccional.
- **Error de IVA, impuestos o contabilización:** revisión funcional SAP y pruebas en sandbox antes de habilitar escritura.
