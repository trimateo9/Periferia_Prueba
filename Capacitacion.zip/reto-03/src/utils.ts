import { createHash } from 'node:crypto';
import { mkdir, readFile, appendFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
export async function readJson<T>(file:string):Promise<T>{return JSON.parse(await readFile(file,'utf8')) as T}
export async function ensureDir(dir:string){await mkdir(dir,{recursive:true})}
export function hash(value:string){return createHash('sha256').update(value).digest('hex')}
export async function logJsonl(root:string,file:string,value:unknown){await ensureDir(path.dirname(path.join(root,file)));await appendFile(path.join(root,file),JSON.stringify(value)+'\n')}
export async function logControl(root:string,row:Record<string,unknown>){const file=path.join(root,'out/control.csv');await ensureDir(path.dirname(file));try{await readFile(file)}catch{await writeFile(file,'solicitud_id,resultado,numero_oc,retroactiva,bloqueos,confirmaciones,ts\n')};const cell=(v:unknown)=>'"'+String(v??'').replaceAll('"','""')+'"';await appendFile(file,[row.solicitud_id,row.resultado,row.numero_oc,row.retroactiva,JSON.stringify(row.bloqueos??[]),JSON.stringify(row.confirmaciones??[]),row.ts].map(cell).join(',')+'\n')}
export function normalize(s:string){return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'')}
