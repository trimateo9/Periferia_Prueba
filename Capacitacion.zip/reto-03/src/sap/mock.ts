import path from 'node:path';
import { readFile, appendFile } from 'node:fs/promises';
import type { OrdenCompra } from '../types.js';
import type { SapAdapter } from './adapter.js';
import { ensureDir, readJson } from '../utils.js';
type SapRow={orden:OrdenCompra;numero_oc:string;fecha:string};
export class MockSapAdapter implements SapAdapter {
 constructor(private root:string){}
 private file(){return path.join(this.root,'out/sap/ordenes.jsonl')}
 private async rows():Promise<SapRow[]>{try{return (await readFile(this.file(),'utf8')).split('\n').filter(Boolean).map(x=>JSON.parse(x) as SapRow)}catch{return []}}
 async consultarProveedor(nit:string){const rows=await readJson<Array<{nit:string;codigo_sap:string;activo:boolean}>>(path.join(this.root,'fixtures/reto-03/maestros/proveedores.json'));const p=rows.find(x=>x.nit===nit);return p?{codigo_sap:p.codigo_sap,activo:p.activo}:null}
 async buscarOrdenPorReferencia(solicitud_id:string){const row=(await this.rows()).find(x=>x.orden.referencia.solicitud_id===solicitud_id);return row?{numero_oc:row.numero_oc}:null}
 async crearOrden(orden:OrdenCompra){const existing=await this.buscarOrdenPorReferencia(orden.referencia.solicitud_id);if(existing)return {...existing,fecha:(await this.rows()).find(x=>x.numero_oc===existing.numero_oc)?.fecha??new Date().toISOString(),idempotente:true} as {numero_oc:string;fecha:string};const rows=await this.rows();const numero=String(4500000001+rows.length);const fecha=new Date().toISOString();await ensureDir(path.dirname(this.file()));await appendFile(this.file(),JSON.stringify({orden,numero_oc:numero,fecha})+'\n');return {numero_oc:numero,fecha};}
}
