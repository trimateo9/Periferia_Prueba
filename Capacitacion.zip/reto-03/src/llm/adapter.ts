export type ChatMessage={role:'system'|'user'|'assistant'|'tool';content:string|null;tool_calls?:Array<{id:string;type:'function';function:{name:string;arguments:string}}>;tool_call_id?:string;name?:string};
export type ToolSpec={type:'function';function:{name:string;description:string;parameters:{type:'object';properties:Record<string,unknown>;required:string[];additionalProperties:false}}};
export type LlmResponse={message:ChatMessage;usage?:{total_tokens?:number}};
export interface LlmAdapter { enviar(mensajes:ChatMessage[],herramientas:ToolSpec[]):Promise<LlmResponse> }
