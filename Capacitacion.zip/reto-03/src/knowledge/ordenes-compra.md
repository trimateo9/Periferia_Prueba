# Conocimiento del proceso de órdenes de compra

## Fuentes y precedencia
La solicitud define descripción, cantidad, precio, total, centro/subárea, moneda y fecha de solicitud. Los maestros definen proveedor SAP activo, tope y aprobadores, indicador IVA y condición de pago. La cotización sirve para comparar el total; nunca se modifica la solicitud para forzar coincidencia. El correo de aprobación es evidencia y debe contener “Aprobado”.

## Controles
- RC1 proveedor por NIT normalizado (o nombre normalizado si no hay NIT) y activo.
- RC2 aprobación existente, explícita y enviada por aprobador autorizado para el centro de costo.
- RC3 total menor o igual al tope del aprobador.
- RC4 subárea perteneciente al centro de costo.
- RC5 diferencia porcentual solicitud/cotización máximo 2%; sin cotización también exige confirmación.
- RC6 IVA faltante se deriva del maestro y requiere confirmación.
- RC7 condición de pago faltante se deriva del maestro y solo se informa.
- RC8 factura anterior a solicitud marca retroactiva y requiere confirmación.
- RC9 aprobación anterior a solicitud requiere confirmación.
- RC10 cantidad por precio unitario debe igualar total con tolerancia de una unidad monetaria.

## Decisiones
Los bloqueos nunca se resuelven por intuición del modelo. Las confirmaciones se presentan a la analista, que debe responder explícitamente. Se conserva evidencia textual con hash SHA-256 y trazabilidad de fuentes para cada grupo de campos del payload.
