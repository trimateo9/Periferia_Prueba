# Reto técnico 03 — Agente conversacional Órdenes de Compra SAP

Aplicación independiente para preparar y validar órdenes de compra a partir de los fixtures del reto, con chat web, ciclo de herramientas, proveedor LLM configurable y adaptador SAP simulado. No conecta a SAP real.

## Requisitos
- Node.js 20+ y npm (o Bun).
- Una clave de un proveedor compatible con OpenAI Chat Completions para usar el chat conversacional. `demo.ts` funciona sin clave.

## Arranque local
```bash
cp .env.example .env
npm install
# Completa LLM_API_KEY y, si aplica, LLM_BASE_URL y LLM_MODEL en .env
npm run dev
```
Abre http://localhost:3000. El servidor carga `.env` automáticamente con `dotenv`.

## Demo sin modelo
```bash
npm install
npm run demo
```
Procesa `sol-001` a `sol-006`, muestra bloqueos y confirmaciones, crea casos de demostración que tienen confirmación explícita en el script y ejecuta `sol-001` dos veces para probar idempotencia. No necesita `LLM_API_KEY`.

## API
- `GET /api/health`: proveedor/modelo y estado de configuración (nunca devuelve la clave).
- `POST /api/chat`: `{ "sessionId": "opcional", "message": "Procesa sol-001" }` → `{ sessionId, reply, toolCalls, needsConfirmation, history }`.
- `GET /api/sessions/:id`: historial visible de la sesión.

## Estructura
- `agent/prompt.md`: comportamiento y políticas del agente.
- `src/knowledge/ordenes-compra.md`: reglas de negocio RC1–RC10.
- `src/tools/oc.ts`: herramientas tipadas con Zod y validación de argumentos.
- `src/llm/`: interfaz y adaptador compatible con OpenAI Chat Completions.
- `src/sap/`: interfaz y mock de SAP basado en archivos.
- `web/`: interfaz de chat.
- `fixtures/reto-03/`: fixtures entregados, copiados sin modificar.
- `out/`: evidencia, payload, trazabilidad, log, control CSV y SAP simulado generados al ejecutar.

## Variables
Consulta `.env.example`. La clave solo se lee en backend y no se registra. Ajusta `MAX_TOOL_ITERATIONS`, `MAX_SESSION_TOKENS` y `LLM_TIMEOUT_MS` para controlar consumo y tiempos.

## Limitaciones conocidas / antes de producción
No hay autenticación, base de datos, lectura binaria real de Excel/PDF, ni integración SAP real. Las sesiones viven en memoria. La demo debe ejecutarse con un único proceso local. Ver `SOLUCION.md` para la propuesta de integración y riesgos.


## Modo demo sin clave LLM

El servidor puede iniciarse sin `LLM_API_KEY`. En ese caso, `/api/health` reporta `mode: "demo-sin-modelo"` y el chat ejecuta el flujo determinista sobre las herramientas reales, sin invocar un proveedor externo. Escribe `Procesa la solicitud sol-001` (o `sol-002` … `sol-006`). Si el caso requiere confirmación, responde `confirmo` para crear la OC o `no` para cancelar. Este modo sirve para validar el flujo de negocio, pero no evalúa la capacidad conversacional del modelo.

Para habilitar el agente conversacional con LLM, configura `LLM_PROVIDER`, `LLM_MODEL`, `LLM_BASE_URL` y `LLM_API_KEY` en `.env`, y reinicia el servidor. Nunca guardes `.env` en Git.
